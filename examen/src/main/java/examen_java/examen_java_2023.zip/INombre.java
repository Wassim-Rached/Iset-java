package examen_java;

public interface INombre {
	public abstract int getNombreChansons();
}
