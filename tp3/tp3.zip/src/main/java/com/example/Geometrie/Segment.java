package com.example.Geometrie;

public class Segment {
	
}
