package com.example.Geometrie;
import java.util.Objects;

public class Cercle {
	private int Rayon;
	private Point Centre;

	public Cercle(Point Centre, int Rayon){
		this.Centre = Centre;
	}

	public Cercle(int abs, int ord, int Rayon){
		this.Rayon = Rayon;
		this.Centre = new Point(abs, ord);
	}

	public int getRayon() {
		return this.Rayon;
	}

	public void setRayon(int Rayon) {
		this.Rayon = Rayon;
	}

	public Point getCentre() {
		return this.Centre;
	}

	public void setCentre(Point Centre) {
		this.Centre = Centre;
	}

	public Cercle Rayon(int Rayon) {
		setRayon(Rayon);
		return this;
	}

	public Cercle Centre(Point Centre) {
		setCentre(Centre);
		return this;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Cercle)) {
			return false;
		}
		Cercle cercle = (Cercle) o;
		return Rayon == cercle.Rayon && Objects.equals(Centre, cercle.Centre);
	}

	@Override
	public int hashCode() {
		return Objects.hash(Rayon, Centre);
	}

	@Override
	public String toString() {
		return "<<" +
			"Centre=" + getCentre() + "," +
			"Rayon=" + getRayon() +
			">>";
	}

	public void SymCercleHoriz(){}
	public void SymCercleVert(){}
}
